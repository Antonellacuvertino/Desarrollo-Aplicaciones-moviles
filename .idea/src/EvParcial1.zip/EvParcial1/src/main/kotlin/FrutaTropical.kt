package org.example

class FrutaTropical(nombre: String, precioPorKilo: Double, stockKilos: Int)
    : Fruta(nombre, precioPorKilo, stockKilos) {

    override fun descripcion(): String {
        return "Fruta tropical $nombre con precio $precioPorKilo y stock $stockKilos"
    }
}
