package org.example

open class Fruta(
    val nombre: String,
    val precioPorKilo: Double,
    val stockKilos: Int
) {
    open fun descripcion(): String {
        return "Fruta: $nombre, Precio: $precioPorKilo, Stock: $stockKilos"
    }
}
