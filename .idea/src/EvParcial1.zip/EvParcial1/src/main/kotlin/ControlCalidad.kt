package org.example
// se imnoorta kotlin delay para hacer el proceso lento dee validacion
import kotlinx.coroutines.delay

// Clase representar los estados del control de calidad
sealed class ResultadoCalidad {
    data class Exitoso(val fruta: Fruta) : ResultadoCalidad()
    data class Error(val motivo: String) : ResultadoCalidad()
}

//en esta funcion podemos simular un control de calidad al inspeccionar una fruta
// aca podemos simular quer el programa esta haciendo un conteo por decirlo asi y se demora en procesar aproximadamente 1 min
suspend fun controlarCalidad(fruta: Fruta): ResultadoCalidad {
    delay(1000L)

    return if (fruta.stockKilos > 0 && fruta.precioPorKilo > 0) {
        ResultadoCalidad.Exitoso(fruta)
    } else {
        ResultadoCalidad.Error("Datos inválidos para ${fruta.nombre}") //cuando un nombre esta vacio o tiene caracteres invalidos el programa marcara un error en la calidad
    }
}
