package org.example

import kotlinx.coroutines.runBlocking
import java.text.DecimalFormat
// Lista mutable donde se guardarán todas las frutas registradas
fun main() = runBlocking {
    val frutas = mutableListOf<Fruta>()
    val formato = DecimalFormat("#,###") // Ej: 1200 -> 1.200

    println("Bienvenido a Puerto Frutal SPA")
    println("¿Cuántas frutas desea registrar?")// aca se pregunta al usuario cuántas frutas registrar
    val cantidad = readLine()?.toIntOrNull() ?: 0
// Ciclo para registrar varias frutas con validación
    repeat(cantidad) { i ->
        println("\nRegistro de fruta ${i + 1}")

        print("Nombre: ")
        val nombre = readLine() ?: "" // Se leen los datos desde la consola

        print("Precio por kilo: ")
        val precio = readLine()?.toDoubleOrNull() ?: -1.0

        print("Stock en kilos: ")
        val stock = readLine()?.toIntOrNull() ?: -1
     //validaciones
        try {
            if (precio <= 0) throw IllegalArgumentException("El precio debe ser mayor a 0")
            if (stock < 0) throw IllegalArgumentException("El stock no puede ser negativo")

            // Alternar entre Local y Tropical para mostrar polimorfismo
            val fruta = if (i % 2 == 0) FrutaLocal(nombre, precio, stock) else FrutaTropical(nombre, precio, stock) // Se crea el objeto FrutaLocal por defecto,puedes variar con FrutaTropical
            frutas.add(fruta)
        } catch (e: Exception) {
            println("Error al registrar fruta: ${e.message}")
        }
    }

    // Preguntar si quiere mostrar frutas
    println("\n¿Desea ver las frutas registradas? (s/n)")
    val opcion = readLine()

    if (opcion.equals("s", ignoreCase = true)) {
        println("\n📋 Lista de frutas registradas:")
        frutas.forEach {
            println("${it.descripcion()} | Precio: ${formato.format(it.precioPorKilo)} | Stock: ${formato.format(it.stockKilos)}")
        }

        println("\nFrutas con precio mayor a 1000:")
        frutas.filter { it.precioPorKilo > 1000 }.forEach {
            println("- ${it.nombre} (${formato.format(it.precioPorKilo)})")
        }

        val total = frutas.sumOf { it.precioPorKilo * it.stockKilos }
        println("\nValor total del stock: ${formato.format(total)}")

        println("\nControl de calidad:")
        for (fruta in frutas) {
            when (val resultado = controlarCalidad(fruta)) {
                is ResultadoCalidad.Exitoso -> println("${fruta.nombre} pasó el control de calidad")
                is ResultadoCalidad.Error -> println("${fruta.nombre} falló: ${resultado.motivo}")
            }
        }
    } else {
        println("Gracias por usar el sistema. ¡Hasta luego:)!")
    }
}
