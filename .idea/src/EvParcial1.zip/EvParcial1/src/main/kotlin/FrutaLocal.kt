package org.example

class FrutaLocal(nombre: String, precioPorKilo: Double, stockKilos: Int)
    : Fruta(nombre, precioPorKilo, stockKilos) {

    override fun descripcion(): String {
        return "Fruta local $nombre con precio $precioPorKilo y stock $stockKilos"
    }
}
